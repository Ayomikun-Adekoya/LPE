<!DOCTYPE html>
<html>
<head>
    <title>Multiple Questions with Radio Buttons</title>
</head>
<body>
    <form method="post" action="">
        <fieldset>
            <legend>Question 1: What is your favorite color?</legend>
            <input type="radio" id="color_red" name="color" value="Red">
            <label for="color_red">Red</label><br>
            <input type="radio" id="color_blue" name="color" value="Blue">
            <label for="color_blue">Blue</label><br>
            <input type="radio" id="color_green" name="color" value="Green">
            <label for="color_green">Green</label><br>
        </fieldset>

        <fieldset>
            <legend>Question 2: What is your favorite animal?</legend>
            <input type="radio" id="animal_dog" name="animal" value="Dog">
            <label for="animal_dog">Dog</label><br>
            <input type="radio" id="animal_cat" name="animal" value="Cat">
            <label for="animal_cat">Cat</label><br>
            <input type="radio" id="animal_bird" name="animal" value="Bird">
            <label for="animal_bird">Bird</label><br>
        </fieldset>

        <input type="submit" name="submit" value="Submit">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if both questions are answered
        if (isset($_POST["color"]) && isset($_POST["animal"])) {
            $selected_color = $_POST["color"];
            $selected_animal = $_POST["animal"];
            echo "Your favorite color is: " . $selected_color . "<br>";
            echo "Your favorite animal is: " . $selected_animal;
        } else {
            echo "Please answer both questions.";
        }
    }
    ?>
</body>
</html>
