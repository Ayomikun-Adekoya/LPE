
<?php
$matric = $_GET['matric'];
$code = $_GET['code'];


$enthusiasm = $_GET["enthusiasm"];
$warmth = $_GET["warmth"];
$credibility = $_GET["credibility"];         
$comment= $_GET['comment'];

    echo $matric. "<br>".$code."<br>".$enthusiasm. "<br>". $warmth."<br>".$credibility. "<br>".$comment;




?>
    
    